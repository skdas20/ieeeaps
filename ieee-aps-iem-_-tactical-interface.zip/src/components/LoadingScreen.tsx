import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export const LoadingScreen: React.FC<{ onFinished: () => void }> = ({ onFinished }) => {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (step < 4) {
        setStep(step + 1);
      } else {
        setTimeout(onFinished, 1000);
      }
    }, 800);
    return () => clearTimeout(timer);
  }, [step, onFinished]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1000] bg-surface-dim flex items-center justify-center overflow-hidden"
    >
      {/* Background HUD Elements */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 font-mono text-[10px] text-primary space-y-1">
          <p>INITIALIZING_CORE_SYSTEMS...</p>
          <p>ESTABLISHING_UPLINK_092...</p>
          <p>DECRYPTING_MISSION_DATA...</p>
        </div>
        <div className="absolute bottom-10 right-10 font-mono text-[10px] text-primary text-right space-y-1">
          <p>LAT: 22.5726 N</p>
          <p>LNG: 88.3639 E</p>
          <p>ALT: 12.4 KM</p>
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,212,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,212,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      <div className="relative flex flex-col items-center">
        <svg width="400" height="200" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Left Waves */}
          <motion.path
            d="M40 160C40 120 70 90 110 90"
            stroke="#004A87"
            strokeWidth="12"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={step >= 1 ? { pathLength: 1, opacity: 1 } : {}}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          <motion.path
            d="M65 160C65 135 85 115 110 115"
            stroke="#00A3AD"
            strokeWidth="12"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={step >= 1 ? { pathLength: 1, opacity: 1 } : {}}
            transition={{ duration: 0.8, ease: "easeInOut", delay: 0.2 }}
          />
          <motion.path
            d="M90 160C90 150 100 140 110 140"
            stroke="#7AB800"
            strokeWidth="12"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={step >= 1 ? { pathLength: 1, opacity: 1 } : {}}
            transition={{ duration: 0.8, ease: "easeInOut", delay: 0.4 }}
          />

          {/* Orange Dot */}
          <motion.circle
            cx="110"
            cy="70"
            r="12"
            fill="#F58220"
            initial={{ scale: 0, opacity: 0 }}
            animate={step >= 2 ? { scale: 1, opacity: 1 } : {}}
            transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.2 }}
          />

          {/* IEEE Text */}
          <motion.text
            x="140"
            y="85"
            fill="#004A87"
            fontSize="60"
            fontWeight="900"
            fontFamily="Inter, sans-serif"
            initial={{ x: 160, opacity: 0 }}
            animate={step >= 3 ? { x: 140, opacity: 1 } : {}}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            IEEE
          </motion.text>

          {/* AP-S Text */}
          <motion.text
            x="140"
            y="160"
            fill="#00838F"
            fontSize="100"
            fontWeight="900"
            fontFamily="Inter, sans-serif"
            initial={{ y: 180, opacity: 0 }}
            animate={step >= 4 ? { y: 160, opacity: 1 } : {}}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            AP-S
          </motion.text>
        </svg>

        {/* Loading Bar */}
        <div className="mt-12 w-64 h-1 bg-surface-container-highest relative overflow-hidden">
          <motion.div
            className="absolute inset-0 bg-primary shadow-[0_0_10px_rgba(0,212,255,0.8)]"
            initial={{ x: "-100%" }}
            animate={{ x: `${(step / 4) * 100 - 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <p className="mt-4 font-label text-[10px] text-primary/60 uppercase tracking-[0.4em] animate-pulse">
          {step === 0 && "Initializing..."}
          {step === 1 && "Forming Signal Waves..."}
          {step === 2 && "Calibrating Core..."}
          {step === 3 && "Loading IEEE Assets..."}
          {step === 4 && "Finalizing AP-S Interface..."}
        </p>
      </div>
    </motion.div>
  );
};
