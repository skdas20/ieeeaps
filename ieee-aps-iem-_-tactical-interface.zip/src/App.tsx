/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, useScroll, useTransform, useSpring, useMotionValue, AnimatePresence } from "motion/react";
import { 
  Network, 
  Terminal, 
  Radar, 
  Satellite, 
  Users, 
  FlaskConical, 
  MapPin, 
  Mail, 
  Globe, 
  Share,
  Menu,
  X,
  Activity,
  Cpu,
  Zap
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { Antenna3D } from "./components/Antenna3D";
import { LoadingScreen } from "./components/LoadingScreen";

const TerminalText = ({ text, delay = 0 }: { text: string; delay?: number }) => {
  const [displayText, setDisplayText] = useState("");
  
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    const startTimeout = setTimeout(() => {
      let i = 0;
      const interval = setInterval(() => {
        setDisplayText(text.slice(0, i));
        i++;
        if (i > text.length) clearInterval(interval);
      }, 50);
      return () => clearInterval(interval);
    }, delay * 1000);
    
    return () => {
      clearTimeout(startTimeout);
      clearTimeout(timeout);
    };
  }, [text, delay]);

  return (
    <span className="font-mono">
      {displayText}
      <motion.span 
        animate={{ opacity: [0, 1, 0] }}
        transition={{ repeat: Infinity, duration: 0.8 }}
        className="inline-block w-2 h-4 bg-primary ml-1 align-middle"
      />
    </span>
  );
};

const TiltCard = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["10deg", "-10deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-10deg", "10deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX, rotateY, transformStyle: "preserve-3d" }}
      className={`relative ${className}`}
    >
      <div style={{ transform: "translateZ(50px)", transformStyle: "preserve-3d" }}>
        {children}
      </div>
    </motion.div>
  );
};

const NavItem = ({ href, label, active = false }: { href: string; label: string; active?: boolean }) => (
  <a 
    href={href} 
    className={`font-label uppercase tracking-[0.2em] text-[10px] font-bold transition-colors duration-300 pb-1 border-b-2 ${
      active ? "text-primary border-primary" : "text-on-surface-variant hover:text-primary border-transparent"
    }`}
  >
    {label}
  </a>
);

const Metric = ({ label, value, progress }: { label: string; value: string; progress: number }) => (
  <div className="space-y-2">
    <div className="flex justify-between text-[10px] font-label uppercase tracking-wider">
      <span className="text-on-surface-variant">{label}</span>
      <span className="text-primary">{value}</span>
    </div>
    <div className="w-full h-[2px] bg-surface-container-highest">
      <motion.div 
        initial={{ width: 0 }}
        whileInView={{ width: `${progress}%` }}
        transition={{ duration: 1.5, ease: "easeOut" }}
        className="bg-primary h-full shadow-[0_0_8px_rgba(0,212,255,0.6)]"
      />
    </div>
  </div>
);

const EventCard = ({ status, code, title, date, image, reportLink }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className="group"
  >
    <div className="relative h-64 overflow-hidden mb-4 border border-outline-variant/20">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale group-hover:grayscale-0"
        referrerPolicy="no-referrer"
      />
      <div className={`absolute top-0 left-0 px-4 py-1 font-label text-[10px] uppercase font-bold tracking-widest ${
        status === 'Upcoming' ? 'bg-primary text-on-primary' : 'bg-secondary text-on-secondary'
      }`}>
        {status}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
      <div className="absolute bottom-4 left-4">
        <p className="font-label text-[10px] text-primary uppercase tracking-widest mb-1">Code: {code}</p>
        <h4 className="font-headline text-lg font-black text-white uppercase tracking-tight">{title}</h4>
      </div>
    </div>
    <div className="flex justify-between items-center px-1">
      <span className="text-[10px] font-label text-on-surface-variant uppercase tracking-widest">{date}</span>
      {status === 'Upcoming' ? (
        <button className="text-[10px] font-label text-on-primary bg-primary px-4 py-1 uppercase tracking-widest font-bold hover:bg-primary/80 transition-colors">Register</button>
      ) : (
        <a href={reportLink} className="text-[10px] font-label text-primary hover:underline uppercase tracking-widest">View Report</a>
      )}
    </div>
  </motion.div>
);

const BenefitCard = ({ icon: Icon, title, description, clearance }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="p-10 bg-surface-container-low border border-outline-variant/10 group hover:border-primary/40 transition-all relative overflow-hidden"
  >
    <div className="absolute top-0 right-0 w-16 h-16 bg-primary/5 -mr-8 -mt-8 rotate-45 group-hover:bg-primary/10 transition-colors" />
    <div className="mb-8 w-14 h-14 bg-primary/5 flex items-center justify-center border border-primary/20 group-hover:bg-primary group-hover:text-on-primary transition-all duration-500">
      <Icon size={24} />
    </div>
    <h3 className="font-headline text-xl font-black mb-4 uppercase text-on-surface tracking-tight">{title}</h3>
    <p className="text-on-surface-variant font-body text-sm leading-relaxed mb-8 opacity-80">
      {description}
    </p>
    <div className="text-[9px] font-label text-primary uppercase tracking-[0.3em] opacity-40 group-hover:opacity-100 transition-opacity">
      {clearance}
    </div>
  </motion.div>
);

const TeamMember = ({ name, role, image, badge }: any) => (
  <motion.div 
    initial={{ opacity: 0 }}
    whileInView={{ opacity: 1 }}
    className="text-center group"
  >
    <div className="relative inline-block mb-6">
      <div className="w-40 h-40 md:w-52 md:h-52 border border-primary/20 p-2 relative">
        <div className="w-full h-full overflow-hidden relative">
          <img 
            src={image} 
            alt={name} 
            className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-110 group-hover:scale-100"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-primary/10 mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
        {/* Corner Accents */}
        <div className="absolute -top-1 -left-1 w-3 h-3 border-t border-l border-primary" />
        <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b border-r border-primary" />
      </div>
      {badge && (
        <div className="absolute -top-2 -right-2 bg-primary text-on-primary px-2 py-0.5 text-[8px] font-label uppercase font-black tracking-widest shadow-lg">
          {badge}
        </div>
      )}
    </div>
    <h4 className="font-headline text-md font-black text-on-surface uppercase mb-1 tracking-tight">{name}</h4>
    <p className="font-label text-[10px] text-primary uppercase tracking-[0.2em]">{role}</p>
  </motion.div>
);

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen selection:bg-primary selection:text-on-primary">
      <AnimatePresence>
        {isLoading && <LoadingScreen onFinished={() => setIsLoading(false)} />}
      </AnimatePresence>

      {/* HUD Scanline Effect */}
      <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
        <div className="scanline" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.2)_100%)]" />
      </div>

      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-[90] transition-all duration-500 border-b ${
        isScrolled ? "bg-surface-dim/95 backdrop-blur-md border-primary/20 py-4" : "bg-transparent border-transparent py-6"
      }`}>
        <div className="max-w-7xl mx-auto px-8 flex justify-between items-center">
          <div className="text-2xl font-black tracking-tighter text-primary glow-text-primary font-headline cursor-pointer">
            IEEE APS <span className="text-white">IEM</span>
          </div>

          <div className="hidden md:flex gap-10 items-center">
            <NavItem href="#" label="Home" active />
            <NavItem href="#about" label="About" />
            <NavItem href="#events" label="Events" />
            <NavItem href="#benefits" label="Benefits" />
            <NavItem href="#team" label="Team" />
            <NavItem href="#contact" label="Contact" />
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden sm:flex items-center gap-4 text-primary/60">
              <Network size={18} className="cursor-pointer hover:text-primary transition-colors" />
              <Terminal size={18} className="cursor-pointer hover:text-primary transition-colors" />
            </div>
            <button className="bg-primary text-on-primary font-label uppercase tracking-widest text-[10px] px-6 py-2.5 font-black hover:bg-white transition-all active:scale-95 glow-primary">
              Join Chapter
            </button>
            <button 
              className="md:hidden text-primary"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden absolute top-full left-0 w-full bg-surface-container-high border-b border-primary/20 p-8 flex flex-col gap-6"
          >
            <a href="#" className="font-label uppercase text-xs tracking-widest text-primary">Home</a>
            <a href="#about" className="font-label uppercase text-xs tracking-widest text-on-surface">About</a>
            <a href="#events" className="font-label uppercase text-xs tracking-widest text-on-surface">Events</a>
            <a href="#team" className="font-label uppercase text-xs tracking-widest text-on-surface">Team</a>
            <a href="#contact" className="font-label uppercase text-xs tracking-widest text-on-surface">Contact</a>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden bg-surface-dim pt-20">
        <motion.div style={{ y, opacity }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-surface-dim z-10" />
          <img 
            src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2072" 
            alt="hero-bg" 
            className="w-full h-full object-cover opacity-20 scale-110"
            referrerPolicy="no-referrer"
          />
          {/* Grid Overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(0,212,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,212,255,0.05)_1px,transparent_1px)] bg-[size:100px_100px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_80%)]" />
        </motion.div>

        <div className="relative z-20 w-full max-w-7xl px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-left">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-block border-l-4 border-primary bg-primary/5 px-6 py-2 mb-8 corner-accent relative"
            >
              <p className="font-label text-[10px] tracking-[0.5em] text-primary uppercase font-bold">
                <TerminalText text="SYSTEM STATUS: ONLINE // AUTH: OMEGA" delay={0.5} />
              </p>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="font-headline text-6xl md:text-8xl font-black text-on-surface mb-6 tracking-tighter leading-[0.85] uppercase"
            >
              IEEE APS <br />
              <span className="text-primary glow-text-primary flicker">IEM CHAPTER</span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="font-body text-lg text-on-surface-variant mb-12 tracking-[0.15em] max-w-xl uppercase font-light leading-relaxed"
            >
              Advancing the frontiers of <span className="text-primary font-bold">Electromagnetics</span>, <span className="text-primary font-bold">Antennas</span>, and <span className="text-primary font-bold">Wave Propagation</span> through tactical innovation.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="flex flex-col sm:flex-row gap-6 items-start"
            >
              <button className="w-full sm:w-auto px-12 py-4 bg-primary text-on-primary font-label font-black uppercase tracking-[0.2em] text-xs glow-primary hover:bg-white transition-all glitch-hover">
                Join the Mission
              </button>
              <button className="w-full sm:w-auto px-12 py-4 border border-primary/40 text-primary font-label font-black uppercase tracking-[0.2em] text-xs hover:bg-primary/10 transition-all">
                View Dossier
              </button>
            </motion.div>
          </div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="hidden lg:block relative"
          >
            <div className="absolute inset-0 bg-primary/10 blur-3xl rounded-full animate-pulse" />
            <div className="relative z-10 border border-primary/20 bg-surface-dim/40 backdrop-blur-sm p-4 corner-accent">
              <Antenna3D />
              <div className="absolute top-4 right-4 flex flex-col gap-2">
                <div className="flex items-center gap-2 text-[8px] font-label text-primary/60 uppercase tracking-widest">
                  <Activity size={10} /> Live Signal
                </div>
                <div className="flex items-center gap-2 text-[8px] font-label text-primary/60 uppercase tracking-widest">
                  <Cpu size={10} /> Processing
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* HUD Elements */}
        <div className="absolute bottom-12 left-12 hidden lg:block border-l-2 border-primary/40 pl-6 py-2">
          <p className="text-[9px] font-label text-primary/50 uppercase tracking-[0.3em] mb-2">Coordinates</p>
          <p className="text-xs font-label text-primary uppercase tracking-widest font-bold">22.5726° N, 88.3639° E</p>
        </div>
        <div className="absolute bottom-12 right-12 hidden lg:block border-r-2 border-primary/40 pr-6 py-2 text-right">
          <p className="text-[9px] font-label text-primary/50 uppercase tracking-[0.3em] mb-2">Scanning Frequency</p>
          <p className="text-xs font-label text-primary uppercase tracking-widest font-bold">2.4 GHz - 5.8 GHz Active</p>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 px-8 bg-surface">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-6 mb-20">
            <h2 className="font-headline text-4xl font-black uppercase tracking-tighter">
              <TerminalText text="CLASSIFIED BRIEFING" delay={1} />
            </h2>
            <div className="h-[1px] flex-grow bg-gradient-to-r from-primary/40 to-transparent" />
            <p className="font-label text-[10px] text-primary/40 tracking-[0.3em] uppercase font-bold">ID: APS-IEM-001</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <TiltCard className="lg:col-span-2">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="glass-panel p-12 border-l-4 border-primary relative group h-full corner-accent"
              >
                <div className="absolute top-6 right-8 text-[9px] font-label text-primary/30 uppercase tracking-widest">Protocol: A-1</div>
                <h3 className="font-headline text-3xl font-black mb-8 text-primary uppercase tracking-tight">Core Directive</h3>
                <p className="text-on-surface-variant leading-relaxed text-xl font-body font-light mb-10 opacity-90">
                  IEEE Antennas and Propagation Society (APS) at IEM Student Branch is an elite division focused on advancing the science of electromagnetics. We explore the boundaries of antenna technology and radio wave propagation through rigorous research and tactical deployment of knowledge.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="bg-surface-container-high/50 p-6 border border-outline-variant/10 hover:border-primary/40 transition-colors group/item">
                    <Radar className="text-primary mb-4 group-hover/item:scale-110 transition-transform" size={32} />
                    <p className="font-label text-[10px] text-primary mb-2 uppercase tracking-widest font-bold">Field Study</p>
                    <p className="text-md text-on-surface font-headline font-bold uppercase">Wave Propagation Analysis</p>
                  </div>
                  <div className="bg-surface-container-high/50 p-6 border border-outline-variant/10 hover:border-primary/40 transition-colors group/item">
                    <Satellite className="text-primary mb-4 group-hover/item:scale-110 transition-transform" size={32} />
                    <p className="font-label text-[10px] text-primary mb-2 uppercase tracking-widest font-bold">Core Tech</p>
                    <p className="text-md text-on-surface font-headline font-bold uppercase">Advanced Antenna Design</p>
                  </div>
                </div>
              </motion.div>
            </TiltCard>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-surface-container-high p-12 flex flex-col justify-between border border-outline-variant/20 corner-accent relative"
            >
              <div>
                <h3 className="font-headline text-2xl font-black mb-10 uppercase tracking-tight">System Metrics</h3>
                <div className="space-y-10">
                  <Metric label="Active Agents" value="150+" progress={85} />
                  <Metric label="Ops Completed" value="42" progress={60} />
                  <Metric label="Tech Readiness" value="Optimal" progress={95} />
                </div>
              </div>
              <div className="mt-12 pt-8 border-t border-outline-variant/20 text-[9px] font-label text-on-surface-variant/40 tracking-widest uppercase">
                Last Sync: <TerminalText text="29/03/26 09:21 UTC" delay={2} />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section id="events" className="py-32 px-8 bg-surface-dim">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div>
              <h2 className="font-headline text-5xl font-black uppercase tracking-tighter mb-4">
                <TerminalText text="MISSION LOG" delay={0.5} />
              </h2>
              <p className="font-label text-[10px] text-primary tracking-[0.4em] uppercase italic font-bold">Past & Future Operations</p>
            </div>
            <div className="flex gap-4">
              <button className="px-8 py-3 bg-surface-container-high border border-outline-variant/20 font-label text-[10px] uppercase tracking-widest text-on-surface-variant hover:text-primary hover:border-primary transition-all font-bold">All Ops</button>
              <button className="px-8 py-3 bg-primary/10 border border-primary/60 font-label text-[10px] uppercase tracking-widest text-primary transition-all font-bold flicker">Active Only</button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            <TiltCard>
              <EventCard 
                status="Completed"
                code="OP-ECHO"
                title="Electromagnetics 101"
                date="JAN 15, 2024"
                image="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800"
                reportLink="#"
              />
            </TiltCard>
            <TiltCard>
              <EventCard 
                status="Upcoming"
                code="OP-SIGNAL"
                title="Antenna Design Masterclass"
                date="JUNE 12, 2024"
                image="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800"
              />
            </TiltCard>
            <TiltCard>
              <EventCard 
                status="Completed"
                code="OP-VOX"
                title="Propagate 2023 Seminar"
                date="DEC 05, 2023"
                image="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800"
                reportLink="#"
              />
            </TiltCard>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-32 px-8 bg-surface">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="font-headline text-5xl font-black uppercase mb-6 tracking-tighter">Personnel Benefits</h2>
            <div className="w-32 h-[2px] bg-primary mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TiltCard>
              <BenefitCard 
                icon={Terminal}
                title="Skill Augmentation"
                description="Access specialized workshops and seminars on electromagnetic theory and practical antenna fabrication protocols."
                clearance="Level 1 Clearance Required"
              />
            </TiltCard>
            <TiltCard>
              <BenefitCard 
                icon={Users}
                title="Tactical Network"
                description="Connect with industry experts, IEEE Distinguished Lecturers, and a global network of A&P researchers."
                clearance="Global Uplink Established"
              />
            </TiltCard>
            <TiltCard>
              <BenefitCard 
                icon={FlaskConical}
                title="Innovation Labs"
                description="Get hands-on experience with simulation tools and hardware testing environments for microwave research."
                clearance="Experimental Protocol Active"
              />
            </TiltCard>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="py-32 px-8 bg-surface-dim">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-headline text-5xl font-black uppercase tracking-tighter mb-24 text-center">Tactical Command</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-16">
            <TiltCard>
              <TeamMember 
                name="Dr. S. Mukherjee"
                role="Faculty Mentor"
                image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800"
                badge="Advisor"
              />
            </TiltCard>
            <TiltCard>
              <TeamMember 
                name="Agent Arnab D."
                role="Chapter Chair"
                image="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=800"
                badge="Executive"
              />
            </TiltCard>
            <TiltCard>
              <TeamMember 
                name="Agent Priya R."
                role="Secretary General"
                image="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=800"
              />
            </TiltCard>
            <TiltCard>
              <TeamMember 
                name="Agent Rahul K."
                role="Tech Lead"
                image="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=800"
              />
            </TiltCard>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-8 bg-surface">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
            <div>
              <h2 className="font-headline text-5xl font-black uppercase tracking-tighter mb-8">
                <TerminalText text="TRANSMISSION TERMINAL" delay={0.5} />
              </h2>
              <p className="text-on-surface-variant font-body text-lg font-light mb-12 max-w-lg opacity-80">
                Initiate a secure communication link for inquiries, collaborations, or mission deployment. All transmissions are encrypted and logged.
              </p>
              
              <div className="space-y-12">
                <div className="flex items-start gap-6 group">
                  <div className="p-3 bg-primary/10 border border-primary/20 text-primary group-hover:bg-primary group-hover:text-on-primary transition-all duration-500">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <p className="font-label text-[10px] uppercase text-primary tracking-[0.3em] mb-2 font-bold">Deployment Zone</p>
                    <p className="text-md font-body font-light uppercase tracking-widest leading-relaxed">
                      Institute of Engineering & Management<br />
                      Salt Lake, Kolkata, West Bengal
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-6 group">
                  <div className="p-3 bg-primary/10 border border-primary/20 text-primary group-hover:bg-primary group-hover:text-on-primary transition-all duration-500">
                    <Mail size={24} />
                  </div>
                  <div>
                    <p className="font-label text-[10px] uppercase text-primary tracking-[0.3em] mb-2 font-bold">Email Uplink</p>
                    <p className="text-md font-body font-light uppercase tracking-widest">comms.aps@iem.edu.in</p>
                  </div>
                </div>
              </div>

              <div className="mt-16 h-64 border border-outline-variant/20 relative grayscale contrast-125 group overflow-hidden corner-accent">
                <img 
                  src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&q=80&w=1000" 
                  alt="map" 
                  className="w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative">
                    <div className="w-12 h-12 bg-primary/20 animate-ping absolute -inset-3 rounded-full" />
                    <div className="w-6 h-6 bg-primary glow-primary relative rounded-full border-2 border-white/20 shadow-[0_0_20px_rgba(0,212,255,0.8)]" />
                  </div>
                </div>
                {/* Map HUD Overlay */}
                <div className="absolute top-4 left-4 font-label text-[8px] text-primary/60 uppercase tracking-widest">
                  Target: HQ_IEM_KOLKATA
                </div>
                <div className="absolute bottom-4 right-4 flex gap-2">
                  <div className="w-1 h-1 bg-primary animate-pulse" />
                  <div className="w-1 h-1 bg-primary animate-pulse delay-75" />
                  <div className="w-1 h-1 bg-primary animate-pulse delay-150" />
                </div>
              </div>
            </div>

            <div className="glass-panel p-12 border border-outline-variant/20 relative">
              <div className="absolute top-0 left-0 w-2 h-2 bg-primary" />
              <div className="absolute top-0 right-0 w-2 h-2 bg-primary" />
              <div className="absolute bottom-0 left-0 w-2 h-2 bg-primary" />
              <div className="absolute bottom-0 right-0 w-2 h-2 bg-primary" />

              <form className="space-y-10">
                <div className="space-y-2">
                  <label className="font-label text-[10px] uppercase tracking-[0.3em] text-primary font-bold">Agent Name</label>
                  <input 
                    type="text" 
                    className="w-full bg-surface-container-highest/30 border-0 border-b-2 border-outline-variant focus:border-primary focus:ring-0 text-on-surface font-label uppercase text-sm tracking-widest py-4 transition-all"
                    placeholder="IDENTIFY YOURSELF"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-label text-[10px] uppercase tracking-[0.3em] text-primary font-bold">Frequency ID (Email)</label>
                  <input 
                    type="email" 
                    className="w-full bg-surface-container-highest/30 border-0 border-b-2 border-outline-variant focus:border-primary focus:ring-0 text-on-surface font-label uppercase text-sm tracking-widest py-4 transition-all"
                    placeholder="EMAIL@DOMAIN.COM"
                  />
                </div>
                <div className="space-y-2">
                  <label className="font-label text-[10px] uppercase tracking-[0.3em] text-primary font-bold">Mission Brief (Message)</label>
                  <textarea 
                    rows={4}
                    className="w-full bg-surface-container-highest/30 border-0 border-b-2 border-outline-variant focus:border-primary focus:ring-0 text-on-surface font-label uppercase text-sm tracking-widest py-4 transition-all resize-none"
                    placeholder="TRANSMISSION DATA..."
                  />
                </div>
                <button className="w-full py-5 bg-primary text-on-primary font-label font-black uppercase tracking-[0.4em] text-xs glow-primary hover:bg-white transition-all active:scale-[0.98]">
                  Send Transmission
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 px-8 bg-surface-dim border-t border-outline-variant/10">
        <div className="max-w-7xl mx-auto flex flex-col items-center gap-12">
          <div className="text-2xl font-black text-on-surface-variant/40 font-headline uppercase tracking-tighter">
            IEEE APS <span className="text-primary/30">IEM</span>
          </div>

          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6">
            <a href="#" className="font-label text-[10px] tracking-[0.2em] uppercase text-on-surface-variant/60 hover:text-primary transition-colors">Privacy Protocol</a>
            <a href="#" className="font-label text-[10px] tracking-[0.2em] uppercase text-on-surface-variant/60 hover:text-primary transition-colors">Security Clearance</a>
            <a href="#" className="font-label text-[10px] tracking-[0.2em] uppercase text-on-surface-variant/60 hover:text-primary transition-colors">Data Logs</a>
            <a href="#" className="font-label text-[10px] tracking-[0.2em] uppercase text-on-surface-variant/60 hover:text-primary transition-colors">Contact Command</a>
          </div>

          <div className="flex gap-10">
            <Globe size={20} className="text-on-surface-variant/30 hover:text-primary cursor-pointer transition-colors" />
            <Network size={20} className="text-on-surface-variant/30 hover:text-primary cursor-pointer transition-colors" />
            <Share size={20} className="text-on-surface-variant/30 hover:text-primary cursor-pointer transition-colors" />
          </div>

          <div className="text-center space-y-4">
            <p className="font-label text-[9px] tracking-[0.3em] uppercase text-on-surface-variant/40">
              © 2026 IEEE APS IEM STUDENT BRANCH. SYSTEM STATUS: OPTIMAL
            </p>
            <div className="flex justify-center items-center gap-3">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
              <span className="text-[9px] font-label text-green-500/60 uppercase tracking-widest font-bold">All systems within normal parameters</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
