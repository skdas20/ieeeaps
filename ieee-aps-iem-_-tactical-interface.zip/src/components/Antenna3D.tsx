import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere, Points, PointMaterial, MeshWobbleMaterial, Torus, Cylinder } from '@react-three/drei';
import * as THREE from 'three';

function SignalWaves() {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.children.forEach((child, i) => {
        const scale = 1 + Math.sin(state.clock.getElapsedTime() * 2 - i * 0.5) * 0.2;
        child.scale.set(scale, scale, scale);
        (child as any).material.opacity = 1 - (scale - 0.8) * 2;
      });
    }
  });

  return (
    <group ref={groupRef}>
      {[1, 2, 3].map((i) => (
        <Torus key={i} args={[i * 0.8, 0.01, 16, 100]}>
          <meshBasicMaterial color="#00D4FF" transparent opacity={0.5} />
        </Torus>
      ))}
    </group>
  );
}

function SatelliteDish() {
  const dishRef = useRef<THREE.Group>(null);
  const armRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (dishRef.current) {
      dishRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.5;
      dishRef.current.rotation.x = Math.cos(state.clock.getElapsedTime() * 0.3) * 0.2;
    }
  });

  return (
    <group ref={dishRef} position={[0, 0, 0]}>
      {/* Main Dish */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <sphereGeometry args={[1.5, 32, 32, 0, Math.PI * 2, 0, Math.PI / 3]} />
        <meshStandardMaterial color="#1A1C1E" wireframe />
      </mesh>
      
      {/* Dish Surface */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <sphereGeometry args={[1.48, 32, 32, 0, Math.PI * 2, 0, Math.PI / 3]} />
        <meshStandardMaterial color="#00D4FF" transparent opacity={0.1} metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Central Receiver Arm */}
      <mesh position={[0, 0, 1.2]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.02, 0.05, 1.5, 8]} />
        <meshStandardMaterial color="#00D4FF" />
      </mesh>

      {/* Receiver Tip */}
      <Sphere args={[0.1, 16, 16]} position={[0, 0, 2]}>
        <MeshWobbleMaterial color="#00D4FF" emissive="#00D4FF" emissiveIntensity={2} factor={0.5} speed={2} />
      </Sphere>

      {/* Rotating Base Elements */}
      <group position={[0, -0.5, 0]}>
        {[0, 1, 2].map((i) => (
          <mesh key={i} rotation={[0, (Math.PI * 2 / 3) * i, 0]} position={[0.5, 0, 0]}>
            <boxGeometry args={[0.1, 0.4, 0.1]} />
            <meshStandardMaterial color="#BE0027" />
          </mesh>
        ))}
      </group>
    </group>
  );
}

function DataParticles() {
  const pointsRef = useRef<THREE.Points>(null);
  const count = 2000;
  
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 10;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 10;
    }
    return pos;
  }, []);

  useFrame((state) => {
    if (pointsRef.current) {
      pointsRef.current.rotation.y = state.clock.getElapsedTime() * 0.05;
      const positions = pointsRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < count; i++) {
        positions[i * 3 + 1] += Math.sin(state.clock.getElapsedTime() + i) * 0.002;
      }
      pointsRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <Points ref={pointsRef} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#00D4FF"
        size={0.015}
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        opacity={0.4}
      />
    </Points>
  );
}

export const Antenna3D: React.FC = () => {
  return (
    <div className="w-full h-full min-h-[450px]">
      <Canvas camera={{ position: [0, 2, 8], fov: 40 }}>
        <color attach="background" args={['#0C0E10']} />
        <ambientLight intensity={0.2} />
        <pointLight position={[10, 10, 10]} intensity={1.5} color="#00D4FF" />
        <spotLight position={[-10, 10, 10]} angle={0.15} penumbra={1} intensity={2} color="#BE0027" />
        
        <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.5}>
          <SatelliteDish />
          <SignalWaves />
        </Float>
        
        <DataParticles />
        
        <gridHelper args={[30, 30, 0x00D4FF, 0x1A1C1E]} position={[0, -3, 0]} opacity={0.1} transparent />
        
        <fog attach="fog" args={['#0C0E10', 5, 15]} />
      </Canvas>
    </div>
  );
};
